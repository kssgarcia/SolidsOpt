from models import CNN_model, UNN_model, ViT_model

from optimize import ESO_stiff, ESO_stress, BESO, SIMP